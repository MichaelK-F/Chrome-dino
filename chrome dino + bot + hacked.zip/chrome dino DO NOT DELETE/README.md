Chrome dino

index - standard version.html :has the standard version of chrome dino.

index - bot version.html :has the bot version (runs by itself, but you can intervine by pressing up/down keys and space bar) of chrome dino.

index - hacked version.html :the dino goes through everything and nothing effeccts it.

index - hacked version + bot version.html :the dino goes through everything and nothing effeccts it, and runs by itself, but you can intervine by pressing up/down keys and space bar

